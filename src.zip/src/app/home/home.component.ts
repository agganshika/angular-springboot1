import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  banner = "/assets/images/banner.jpg";
  youtubefront = "/assets/images/1.png";
  testproject1 = "/assets/images/4.png";
  testproject2 = "/assets/images/5.png";
  testproject3 = "/assets/images/6.png";
  allvideos = "/assets/images/2.png";
  instagram = "/assets/images/1.png";
  
  constructor() { }

  ngOnInit() {
  }

}
