export class User{
    constructor(
        username : string,
        firstname : string,
        lastname : string,
        age : number,
        password : string
    ){}
}